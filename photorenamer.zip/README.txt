JPN
1.
リネーム(名前を変更)する必要のある写真/ファイルだけを集めたフォルダを作ってください。
つまり、元データは安全のため残しておいてください。

2.
pr.bat
start.bat
を写真があるフォルダに一緒に入れてください

3.start.batをダブルクリック

////////////////////////////////

image.1という名前が気に入らなかったら、

start.bat を右クリック→編集

image jpg と書いてあるところをうまいこと編集してください。

例えば
tokyo jpg
usj jpg
mago jpg などです。

_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
ENG

Put 2 files - pr.bat and start.bat to photos directory.

click start.bat

dont warry this is just bat
to make me confort when i write my travel blog.

